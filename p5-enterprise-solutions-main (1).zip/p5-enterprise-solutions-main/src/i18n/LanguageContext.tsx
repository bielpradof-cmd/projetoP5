import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Locale, Translations } from './types';
import { ptBR } from './pt-BR';
import { enUS } from './en-US';
import { esES } from './es-ES';

const translationMap: Record<Locale, Translations> = {
  'pt-BR': ptBR,
  'en-US': enUS,
  'es-ES': esES,
};

interface LanguageContextValue {
  locale: Locale;
  setLocale: (locale: Locale) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextValue | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [locale, setLocaleState] = useState<Locale>(() => {
    const stored = localStorage.getItem('p5-locale') as Locale | null;
    return stored && translationMap[stored] ? stored : 'pt-BR';
  });

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    localStorage.setItem('p5-locale', l);
    document.documentElement.lang = l;
  }, []);

  const t = translationMap[locale];

  return (
    <LanguageContext.Provider value={{ locale, setLocale, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = (): LanguageContextValue => {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useLanguage must be used within LanguageProvider');
  return ctx;
};
