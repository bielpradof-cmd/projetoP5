export type Locale = 'pt-BR' | 'en-US' | 'es-ES';

export interface LocaleConfig {
  code: Locale;
  label: string;
  short: string;
}

export const locales: LocaleConfig[] = [
  { code: 'pt-BR', label: 'Português', short: 'PT' },
  { code: 'en-US', label: 'English', short: 'EN' },
  { code: 'es-ES', label: 'Español', short: 'ES' },
];

export interface Translations {
  nav: {
    solutions: string;
    whiteLabel: string;
    about: string;
    scheduleDiagnostic: string;
  };
  hero: {
    authorityBadge: string;
    headline1: string;
    headline2: string;
    headline3: string;
    subheadline: string;
    ctaPrimary: string;
    ctaSecondary: string;
    metric1Label: string;
    metric2Label: string;
    metric3Label: string;
    dashboardTitle: string;
    dashboardPipeline: string;
    dashboardDeals: string;
    dashboardAutomation: string;
    dashboardAutomationDesc: string;
    dashboardAIScore: string;
  };
  kanban: {
    col1: string;
    col2: string;
    col3: string;
    col4: string;
    pipelineTotal: string;
    brandLabel: string;
    brandTagline: string;
    toggleDark: string;
    toggleLight: string;
    tooltip: string;
    tooltipMobile: string;
    scrollHint: string;
  };
  problem: {
    sectionLabel: string;
    heading: string;
    body: string;
    card1Heading: string;
    card1Body: string;
    card2Heading: string;
    card2Body: string;
    card3Heading: string;
    card3Body: string;
  };
  solutions: {
    sectionLabel: string;
    heading: string;
    card1Subtitle: string;
    card1Title: string;
    card1Body: string;
    card1Features: string[];
    card2Subtitle: string;
    card2Title: string;
    card2Body: string;
    card2Features: string[];
    card3Subtitle: string;
    card3Title: string;
    card3Body: string;
    card3Features: string[];
    learnMore: string;
  };
  whiteLabel: {
    sectionLabel: string;
    heading1: string;
    heading2: string;
    heading3: string;
    body: string;
    pillar1Title: string;
    pillar1Body: string;
    pillar2Title: string;
    pillar2Body: string;
    pillar3Title: string;
    pillar3Body: string;
    closingStatement: string;
    cta: string;
  };
  framework: {
    sectionLabel: string;
    heading: string;
    p1Name: string;
    p1Desc: string;
    p2Name: string;
    p2Desc: string;
    p3Name: string;
    p3Desc: string;
    p4Name: string;
    p4Desc: string;
    p5Name: string;
    p5Desc: string;
  };
  infrastructure: {
    sectionLabel: string;
    heading: string;
    body: string;
    metricsBar: string;
    badge1: string;
    badge2: string;
    badge3: string;
    badge4: string;
  };
  cta: {
    sectionLabel: string;
    heading: string;
    body: string;
    button: string;
    trust1: string;
    trust2: string;
    trust3: string;
  };
  footer: {
    tagline: string;
    location: string;
    solutionsLabel: string;
    solutionsLinks: string[];
    companyLabel: string;
    companyLinks: string[];
    partnerLabel: string;
    partnerLinks: string[];
    copyright: string;
    privacy: string;
    terms: string;
    cookies: string;
  };
  floatingDiagnostic: string;
}
