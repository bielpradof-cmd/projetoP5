import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import ProblemSection from '@/components/ProblemSection';
import SolutionsSection from '@/components/SolutionsSection';
import WhiteLabelSection from '@/components/WhiteLabelSection';
import FrameworkSection from '@/components/FrameworkSection';
import InfrastructureSection from '@/components/InfrastructureSection';
import CTASection from '@/components/CTASection';
import Footer from '@/components/Footer';
import { KanbanStateProvider } from '@/components/KanbanStateProvider';

const Index = () => {
  return (
    <KanbanStateProvider>
      <Navigation />
      <main>
        <HeroSection />
        <ProblemSection />
        <SolutionsSection />
        <WhiteLabelSection />
        <FrameworkSection />
        <InfrastructureSection />
        <CTASection />
      </main>
      <Footer />
    </KanbanStateProvider>
  );
};

export default Index;
