export const SITE_METRICS = {
  gmvMonthly: 'R$ 50M+',
  activeClients: '300.000+',
  wlRetentionRate: '100%',
} as const;

export const WHATSAPP_URL = 'https://wa.me/5541995808581';
