import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/i18n/LanguageContext';
import { SITE_METRICS, WHATSAPP_URL } from '@/siteConfig';
import HeroDashboard from './HeroDashboard';

const HeroSection = () => {
  const [visible, setVisible] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const timer = setTimeout(() => setVisible(true), 150);
    return () => clearTimeout(timer);
  }, []);

  const metrics = [
    { value: SITE_METRICS.gmvMonthly, label: t.hero.metric1Label },
    { value: SITE_METRICS.activeClients, label: t.hero.metric2Label },
    { value: SITE_METRICS.wlRetentionRate, label: t.hero.metric3Label },
  ];

  return (
    <section className="relative min-h-screen flex items-center pt-16 overflow-hidden" style={{ background: 'linear-gradient(180deg, hsl(222, 47%, 8%) 0%, hsl(222, 40%, 11%) 50%, hsl(220, 30%, 14%) 100%)' }}>
      {/* Subtle grid pattern */}
      <div className="absolute inset-0 pointer-events-none" style={{ opacity: 0.04 }}>
        <svg width="100%" height="100%">
          <defs>
            <pattern id="hero-grid" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 48 0 L 0 0 0 48" fill="none" stroke="white" strokeWidth="0.5" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#hero-grid)" />
        </svg>
      </div>

      {/* Radial glow */}
      <div
        className="absolute pointer-events-none"
        style={{
          top: '10%',
          right: '5%',
          width: '700px',
          height: '700px',
          background: 'radial-gradient(circle, hsla(222, 76%, 49%, 0.08) 0%, transparent 70%)',
        }}
      />

      <div className="relative z-10 w-full max-w-content mx-auto px-6 md:px-8 py-14 md:py-18 lg:py-24">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-10 items-center">
          {/* Left: Copy */}
          <div
            className="lg:col-span-6 transition-all duration-[900ms] ease-[cubic-bezier(0.25,0.1,0.25,1)]"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? 'translateY(0)' : 'translateY(24px)',
            }}
          >
            {/* Authority badge */}
            <div className="inline-flex items-center gap-2 mb-8 px-3 py-1.5 rounded-full border border-white/10 bg-white/5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
              <span className="text-xs font-medium text-white/60 tracking-wide">{t.hero.authorityBadge}</span>
            </div>

            <h1 className="text-display-1 mb-6">
              <span className="block text-white">{t.hero.headline1}</span>
              <span className="block" style={{ color: 'hsl(222, 76%, 62%)' }}>{t.hero.headline2}</span>
              <span className="block text-white">{t.hero.headline3}</span>
            </h1>

            <p className="text-body-large text-white/50 max-w-[540px] mb-10 leading-relaxed">
              {t.hero.subheadline}
            </p>

            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 mb-14">
              <a
                href={WHATSAPP_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center w-full sm:w-auto px-7 py-3.5 text-base font-semibold rounded-lg text-white transition-all duration-200 min-h-[48px]"
                style={{
                  background: 'linear-gradient(135deg, hsl(222, 76%, 49%) 0%, hsl(222, 76%, 42%) 100%)',
                  boxShadow: '0 4px 24px -4px hsla(222, 76%, 49%, 0.4)',
                }}
              >
                {t.hero.ctaPrimary}
              </a>
              <a
                href="#solutions"
                className="inline-flex items-center gap-2 text-base text-white/60 transition-colors duration-200 hover:text-white text-center sm:text-left group"
              >
                {t.hero.ctaSecondary}
                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" className="transition-transform duration-200 group-hover:translate-x-0.5">
                  <path d="M6 4l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
            </div>

            {/* Metrics strip */}
            <div className="flex flex-col sm:flex-row sm:items-start sm:divide-x sm:divide-white/10">
              {metrics.map((metric, i) => (
                <div
                  key={i}
                  className={`py-3 sm:py-0 ${i > 0 ? 'sm:pl-6 border-t sm:border-t-0 border-white/10' : ''} ${i < 2 ? 'sm:pr-6' : ''} text-center sm:text-left`}
                >
                  <p className="text-2xl md:text-[28px] font-bold text-white leading-tight">{metric.value}</p>
                  <p className="text-xs text-white/40 mt-1 font-medium">{metric.label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Enterprise CRM Dashboard */}
          <div
            className="hidden lg:block lg:col-span-6 transition-all duration-[1000ms] ease-[cubic-bezier(0.25,0.1,0.25,1)] delay-200"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? 'translateY(0) perspective(1200px) rotateY(-2deg)' : 'translateY(32px) perspective(1200px) rotateY(-4deg)',
            }}
          >
            <HeroDashboard />
          </div>
        </div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 pointer-events-none" style={{ background: 'linear-gradient(to top, hsl(220, 30%, 14%), transparent)' }} />
    </section>
  );
};

export default HeroSection;
