import { Crown, Tag, TrendingUp } from 'lucide-react';
import { useIntersectionObserver, useStaggeredChildren } from '@/hooks/useIntersectionObserver';
import { useLanguage } from '@/i18n/LanguageContext';
import { WHATSAPP_URL } from '@/siteConfig';
import InteractiveCRMKanban from './InteractiveCRMKanban';

const WhiteLabelSection = () => {
  const { ref, isVisible } = useIntersectionObserver();
  const childrenVisible = useStaggeredChildren(isVisible, 3);
  const { t } = useLanguage();

  const pillars = [
    { icon: Crown, title: t.whiteLabel.pillar1Title, body: t.whiteLabel.pillar1Body },
    { icon: Tag, title: t.whiteLabel.pillar2Title, body: t.whiteLabel.pillar2Body },
    { icon: TrendingUp, title: t.whiteLabel.pillar3Title, body: t.whiteLabel.pillar3Body },
  ];

  return (
    <section
      id="white-label"
      ref={ref as React.RefObject<HTMLElement>}
      className="bg-p5-surface border-y border-p5-border py-14 md:py-18 lg:py-30"
    >
      <div className="w-full max-w-content mx-auto px-4 md:px-8">
        <p
          className="text-caption text-p5-action mb-10 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
        >
          {t.whiteLabel.sectionLabel}
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          <div
            className="transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
            style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
          >
            <h2 className="text-display-2 text-p5-text-primary mb-6">
              <span className="block">{t.whiteLabel.heading1}</span>
              <span className="block text-p5-action">{t.whiteLabel.heading2}</span>
              <span className="block">{t.whiteLabel.heading3}</span>
            </h2>
            <p className="text-body-large text-p5-text-secondary mb-10 max-w-[540px]">
              {t.whiteLabel.body}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
              {pillars.map((pillar, i) => (
                <div
                  key={i}
                  className="group bg-p5-bg border border-p5-border rounded-lg p-5 transition-all duration-300"
                  style={{
                    opacity: childrenVisible[i] ? 1 : 0,
                    transform: childrenVisible[i] ? 'translateY(0)' : 'translateY(16px)',
                  }}
                  onMouseEnter={(e) => {
                    e.currentTarget.style.borderColor = 'hsl(222, 76%, 49%)';
                    e.currentTarget.style.boxShadow = '0 0 0 3px hsla(222, 76%, 49%, 0.08)';
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget.style.borderColor = '';
                    e.currentTarget.style.boxShadow = '';
                  }}
                >
                  <div className="w-10 h-10 rounded-lg bg-p5-action-surface flex items-center justify-center mb-3 transition-transform duration-300 group-hover:rotate-6">
                    <pillar.icon size={20} strokeWidth={1.5} className="text-p5-action" />
                  </div>
                  <h3 className="text-sm font-semibold text-p5-text-primary mb-2">{pillar.title}</h3>
                  <p className="text-xs text-p5-text-secondary leading-relaxed">{pillar.body}</p>
                </div>
              ))}
            </div>

            <p className="text-xl font-medium text-p5-text-secondary max-w-[720px] mb-10 leading-relaxed">
              {t.whiteLabel.closingStatement}
            </p>

            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center px-7 py-3.5 text-base font-semibold rounded-lg text-white transition-all duration-200 min-h-[48px]"
              style={{
                background: 'linear-gradient(135deg, hsl(222, 76%, 49%) 0%, hsl(222, 76%, 42%) 100%)',
                boxShadow: '0 4px 24px -4px hsla(222, 76%, 49%, 0.3)',
              }}
            >
              {t.whiteLabel.cta}
            </a>
          </div>
          <div
            className="hidden lg:flex items-center justify-end transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)] delay-200"
            style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
          >
            <InteractiveCRMKanban darkSurface={false} showBrandHeader showModeToggle minColumnHeight={360} />
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhiteLabelSection;
