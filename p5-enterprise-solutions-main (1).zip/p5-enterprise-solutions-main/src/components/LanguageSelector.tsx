import { useState, useRef, useEffect } from 'react';
import { useLanguage } from '@/i18n/LanguageContext';
import type { Locale } from '@/i18n/types';

const BrazilFlag = () => (
  <svg viewBox="0 0 28 28" width="28" height="28" className="block">
    <clipPath id="br-clip"><circle cx="14" cy="14" r="14" /></clipPath>
    <g clipPath="url(#br-clip)">
      <rect width="28" height="28" fill="#009739" />
      <path d="M14 4 L26 14 L14 24 L2 14 Z" fill="#FEDD00" />
      <circle cx="14" cy="14" r="5.5" fill="#012169" />
      <path d="M9 14.5 Q14 12, 19 14.5" stroke="white" strokeWidth="0.8" fill="none" />
    </g>
  </svg>
);

const USFlag = () => (
  <svg viewBox="0 0 28 28" width="28" height="28" className="block">
    <clipPath id="us-clip"><circle cx="14" cy="14" r="14" /></clipPath>
    <g clipPath="url(#us-clip)">
      <rect width="28" height="28" fill="#B22234" />
      {[0,1,2,3,4,5].map(i => (
        <rect key={i} y={2.15 * (2*i+1)} width="28" height="2.15" fill="white" />
      ))}
      <rect width="11.2" height="15.05" fill="#3C3B6E" />
      {[1,3,5,7,9].map((r,ri) => (
        [0,1,2,3,4,5].slice(0, ri % 2 === 0 ? 6 : 5).map((_,ci) => (
          <circle key={`${r}-${ci}`} cx={1 + ci * 1.85 + (ri % 2 === 0 ? 0 : 0.925)} cy={0.75 + ri * 1.5} r="0.5" fill="white" />
        ))
      ))}
    </g>
  </svg>
);

const SpainFlag = () => (
  <svg viewBox="0 0 28 28" width="28" height="28" className="block">
    <clipPath id="es-clip"><circle cx="14" cy="14" r="14" /></clipPath>
    <g clipPath="url(#es-clip)">
      <rect width="28" height="7" fill="#AA151B" />
      <rect y="7" width="28" height="14" fill="#F1BF00" />
      <rect y="21" width="28" height="7" fill="#AA151B" />
    </g>
  </svg>
);

const flagMap: Record<Locale, React.FC> = {
  'pt-BR': BrazilFlag,
  'en-US': USFlag,
  'es-ES': SpainFlag,
};

const localeOrder: Locale[] = ['pt-BR', 'en-US', 'es-ES'];

const LanguageSelector = () => {
  const { locale, setLocale } = useLanguage();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const ActiveFlag = flagMap[locale];

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="w-7 h-7 rounded-full overflow-hidden focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[hsl(222,76%,49%)]"
        aria-label="Select language"
        aria-expanded={open}
      >
        <ActiveFlag />
      </button>

      {open && (
        <div
          className="absolute right-0 top-full mt-2 w-12 bg-white border border-[hsl(220,13%,91%)] rounded-md p-1.5 z-50 flex flex-col items-center gap-1.5"
          style={{ boxShadow: '0 4px 16px 0 rgba(0,0,0,0.08)' }}
          role="listbox"
        >
          {localeOrder.map(code => {
            const Flag = flagMap[code];
            const isActive = code === locale;
            return (
              <button
                key={code}
                role="option"
                aria-selected={isActive}
                onClick={() => { setLocale(code); setOpen(false); }}
                className="w-7 h-7 rounded-full overflow-hidden shrink-0"
                style={isActive ? { outline: '2px solid hsl(222,76%,49%)', outlineOffset: '1px' } : undefined}
              >
                <Flag />
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;
