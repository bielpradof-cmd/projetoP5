import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';

export type ColumnId = 'prospeccao' | 'qualificacao' | 'proposta' | 'fechamento';

export interface KanbanCard {
  id: string;
  company: string;
  segment: string;
  value: number;
  score: number;
  column: ColumnId;
}

const initialCards: KanbanCard[] = [
  { id: '1', company: 'TechNova Soluções', segment: 'SaaS', value: 45000, score: 92, column: 'prospeccao' },
  { id: '2', company: 'Grupo Vertice', segment: 'Indústria', value: 120000, score: 87, column: 'qualificacao' },
  { id: '3', company: 'DataFlow Analytics', segment: 'Dados', value: 68000, score: 78, column: 'qualificacao' },
  { id: '4', company: 'MedLab Solutions', segment: 'Saúde', value: 95000, score: 95, column: 'proposta' },
  { id: '5', company: 'Porto Digital', segment: 'Fintech', value: 150000, score: 88, column: 'proposta' },
  { id: '6', company: 'Logística Prime', segment: 'Logística', value: 72000, score: 65, column: 'prospeccao' },
  { id: '7', company: 'Rede Conecta', segment: 'Telecom', value: 88000, score: 71, column: 'qualificacao' },
  { id: '8', company: 'AgroTech Brasil', segment: 'Agro', value: 200000, score: 84, column: 'fechamento' },
  { id: '9', company: 'Construir+', segment: 'Construção', value: 55000, score: 59, column: 'prospeccao' },
  { id: '10', company: 'EduSmart', segment: 'EdTech', value: 38000, score: 76, column: 'fechamento' },
];

interface KanbanContextValue {
  cards: KanbanCard[];
  moveCard: (cardId: string, toColumn: ColumnId) => void;
  pipelineTotal: number;
}

const KanbanContext = createContext<KanbanContextValue | undefined>(undefined);

export const KanbanStateProvider = ({ children }: { children: ReactNode }) => {
  const [cards, setCards] = useState<KanbanCard[]>(initialCards);

  const moveCard = useCallback((cardId: string, toColumn: ColumnId) => {
    setCards(prev => prev.map(c => c.id === cardId ? { ...c, column: toColumn } : c));
  }, []);

  const pipelineTotal = cards.reduce((sum, c) => sum + c.value, 0);

  return (
    <KanbanContext.Provider value={{ cards, moveCard, pipelineTotal }}>
      {children}
    </KanbanContext.Provider>
  );
};

export const useKanbanState = (): KanbanContextValue => {
  const ctx = useContext(KanbanContext);
  if (!ctx) throw new Error('useKanbanState must be used within KanbanStateProvider');
  return ctx;
};
