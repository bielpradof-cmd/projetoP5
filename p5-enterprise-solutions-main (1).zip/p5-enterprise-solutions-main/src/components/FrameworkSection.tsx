import { Workflow, Users, BarChart3, Layers, Target } from 'lucide-react';
import { useIntersectionObserver, useStaggeredChildren } from '@/hooks/useIntersectionObserver';
import { useLanguage } from '@/i18n/LanguageContext';

const FrameworkSection = () => {
  const { ref, isVisible } = useIntersectionObserver();
  const childrenVisible = useStaggeredChildren(isVisible, 5);
  const { t } = useLanguage();

  const pillars = [
    { icon: Workflow, num: 'P1', name: t.framework.p1Name, desc: t.framework.p1Desc },
    { icon: Users, num: 'P2', name: t.framework.p2Name, desc: t.framework.p2Desc },
    { icon: BarChart3, num: 'P3', name: t.framework.p3Name, desc: t.framework.p3Desc },
    { icon: Layers, num: 'P4', name: t.framework.p4Name, desc: t.framework.p4Desc },
    { icon: Target, num: 'P5', name: t.framework.p5Name, desc: t.framework.p5Desc },
  ];

  return (
    <section id="framework" ref={ref as React.RefObject<HTMLElement>} className="relative py-14 md:py-18 lg:py-30 overflow-hidden" style={{ background: 'hsl(220, 20%, 97%)' }}>
      <div className="w-full max-w-content mx-auto px-4 md:px-8">
        <div
          className="mb-14 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
        >
          <p className="text-caption text-p5-action mb-4">{t.framework.sectionLabel}</p>
          <h2 className="text-heading-1 text-p5-text-primary max-w-[640px]">{t.framework.heading}</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-8">
          {pillars.map((p, i) => (
            <div
              key={i}
              className="group transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
              style={{
                opacity: childrenVisible[i] ? 1 : 0,
                transform: childrenVisible[i] ? 'translateY(0)' : 'translateY(16px)',
              }}
            >
              <div className="w-10 h-10 rounded-lg bg-p5-action-surface flex items-center justify-center mb-4 transition-transform duration-300 group-hover:rotate-6">
                <p.icon size={20} strokeWidth={1.5} className="text-p5-action" />
              </div>
              <p className="text-4xl font-bold text-p5-action mb-2" style={{ opacity: 0.2 }}>{p.num}</p>
              <p className="text-lg font-semibold text-p5-text-primary mb-2">{p.name}</p>
              <p className="text-sm text-p5-text-secondary leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FrameworkSection;
