import { useState, useRef, useEffect, type DragEvent } from 'react';
import { useKanbanState, type ColumnId } from './KanbanStateProvider';
import { useLanguage } from '@/i18n/LanguageContext';
import { Moon, Sun } from 'lucide-react';

interface InteractiveCRMKanbanProps {
  darkSurface?: boolean;
  showBrandHeader?: boolean;
  showModeToggle?: boolean;
  minColumnHeight?: number;
}

const columns: ColumnId[] = ['prospeccao', 'qualificacao', 'proposta', 'fechamento'];

const formatCurrency = (value: number) =>
  `R$ ${value.toLocaleString('pt-BR')}`;

const getScoreColor = (score: number, isDark: boolean) => {
  if (score >= 85) return isDark ? 'text-emerald-400' : 'text-emerald-600';
  if (score >= 70) return isDark ? 'text-amber-400' : 'text-amber-600';
  return isDark ? 'text-red-400' : 'text-red-500';
};

const InteractiveCRMKanban = ({
  darkSurface = true,
  showBrandHeader = false,
  showModeToggle = false,
  minColumnHeight = 320,
}: InteractiveCRMKanbanProps) => {
  const { cards, moveCard } = useKanbanState();
  const { t } = useLanguage();
  const [dragOverCol, setDragOverCol] = useState<ColumnId | null>(null);
  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [mode, setMode] = useState<'dark' | 'light'>(darkSurface ? 'dark' : 'light');
  const [showHint, setShowHint] = useState(false);
  const hintTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  const isDark = mode === 'dark';

  useEffect(() => {
    return () => {
      if (hintTimeout.current) clearTimeout(hintTimeout.current);
    };
  }, []);

  const handleMouseEnter = () => {
    if (hintTimeout.current) clearTimeout(hintTimeout.current);
    setShowHint(true);
  };

  const handleMouseLeave = () => {
    hintTimeout.current = setTimeout(() => setShowHint(false), 2000);
  };

  const colLabels: Record<ColumnId, string> = {
    prospeccao: t.kanban.col1,
    qualificacao: t.kanban.col2,
    proposta: t.kanban.col3,
    fechamento: t.kanban.col4,
  };

  const handleDragStart = (e: DragEvent, cardId: string) => {
    e.dataTransfer.setData('text/plain', cardId);
    e.dataTransfer.effectAllowed = 'move';
    setDraggingId(cardId);
  };

  const handleDragOver = (e: DragEvent, colId: ColumnId) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverCol(colId);
  };

  const handleDragLeave = () => setDragOverCol(null);

  const handleDrop = (e: DragEvent, colId: ColumnId) => {
    e.preventDefault();
    const cardId = e.dataTransfer.getData('text/plain');
    if (cardId) moveCard(cardId, colId);
    setDragOverCol(null);
    setDraggingId(null);
  };

  const handleDragEnd = () => {
    setDragOverCol(null);
    setDraggingId(null);
  };

  const bg = isDark ? 'bg-[#111111]' : 'bg-[#FAFAFA]';
  const borderCol = isDark ? 'border-[#1F1F1F]' : 'border-[hsl(220,13%,91%)]';
  const cardBg = isDark ? 'bg-[#1A1A1A]' : 'bg-white';
  const cardBorder = isDark ? 'border-[#2A2A2A]' : 'border-[hsl(220,13%,91%)]';
  const textPrimary = isDark ? 'text-white' : 'text-[#0A0A0A]';
  const textSecondary = isDark ? 'text-[#9CA3AF]' : 'text-[#6B7280]';
  const textMuted = isDark ? 'text-[#6B7280]' : 'text-[#9CA3AF]';
  const colBg = isDark ? 'bg-[#0A0A0A]' : 'bg-[#F9FAFB]';
  const dropHighlight = isDark ? 'bg-[#1A1A2E]' : 'bg-[#EFF6FF]';

  return (
    <div
      className={`${bg} border ${borderCol} rounded-lg overflow-hidden w-full relative`}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Tooltip - desktop only */}
      <div
        className="hidden md:block absolute left-1/2 z-20 whitespace-nowrap bg-white border border-[hsl(220,13%,91%)] rounded-md px-4 py-2.5 text-[13px] font-medium text-[#0A0A0A]"
        style={{
          top: '-56px',
          transform: showHint ? 'translateX(-50%) translateY(0)' : 'translateX(-50%) translateY(4px)',
          opacity: showHint ? 1 : 0,
          pointerEvents: showHint ? 'auto' : 'none',
          transition: 'opacity 200ms ease, transform 200ms ease',
          boxShadow: '0 4px 16px 0 rgba(0,0,0,0.08)',
        }}
      >
        {t.kanban.tooltip}
        <div
          className="absolute left-1/2 -translate-x-1/2 w-0 h-0"
          style={{
            bottom: '-6px',
            borderLeft: '6px solid transparent',
            borderRight: '6px solid transparent',
            borderTop: '6px solid white',
          }}
        />
      </div>

      {/* Header */}
      <div className={`flex items-center justify-between px-3 py-2.5 border-b ${borderCol}`}>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1.5">
            <div className="w-2 h-2 rounded-full bg-[hsl(0,70%,55%)]" />
            <div className="w-2 h-2 rounded-full bg-[hsl(45,80%,55%)]" />
            <div className="w-2 h-2 rounded-full bg-[hsl(130,50%,50%)]" />
          </div>
          <span className={`ml-2 text-[11px] font-semibold ${textSecondary}`}>
            {showBrandHeader ? t.kanban.brandLabel : 'P5 CRM'}
          </span>
        </div>
        <div className="flex items-center gap-2">
          {showModeToggle && (
            <button
              onClick={() => setMode(m => m === 'dark' ? 'light' : 'dark')}
              className={`flex items-center gap-1 px-2 py-1 rounded text-[10px] font-medium transition-colors duration-200 ${
                isDark
                  ? 'bg-[#1F1F1F] text-[#9CA3AF] hover:text-white'
                  : 'bg-[#F3F4F6] text-[#6B7280] hover:text-[#0A0A0A]'
              }`}
              aria-label="Toggle mode"
            >
              {isDark ? <Sun size={10} /> : <Moon size={10} />}
              {isDark ? t.kanban.toggleLight : t.kanban.toggleDark}
            </button>
          )}
          <span className={`text-[10px] font-medium ${textMuted}`}>
            {t.kanban.pipelineTotal}: {formatCurrency(cards.reduce((s, c) => s + c.value, 0))}
          </span>
        </div>
      </div>

      {showBrandHeader && (
        <div className={`px-3 py-2 border-b ${borderCol}`}>
          <p className={`text-[11px] font-normal ${textMuted}`}>{t.kanban.brandTagline}</p>
        </div>
      )}

      {/* Mobile hint */}
      <p className="md:hidden text-[12px] text-p5-text-tertiary px-3 py-1.5">{t.kanban.tooltipMobile}</p>

      {/* Columns - horizontally scrollable on mobile */}
      <div className="flex md:grid md:grid-cols-4 gap-0 overflow-x-auto md:overflow-visible" style={{ WebkitOverflowScrolling: 'touch' }}>
        {columns.map(colId => {
          const colCards = cards.filter(c => c.column === colId);
          const isOver = dragOverCol === colId;
          return (
            <div
              key={colId}
              className={`${isOver ? dropHighlight : colBg} border-r last:border-r-0 ${borderCol} p-2 transition-colors duration-150 min-w-[240px] md:min-w-0 flex-shrink-0 md:flex-shrink`}
              style={{ minHeight: minColumnHeight }}
              onDragOver={(e) => handleDragOver(e, colId)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, colId)}
            >
              <div className="flex items-center justify-between mb-2 px-0.5">
                <span className={`text-[11px] font-semibold ${textSecondary}`}>{colLabels[colId]}</span>
                <span className={`text-[10px] ${textMuted}`}>{colCards.length}</span>
              </div>
              <div className="flex flex-col gap-1.5">
                {colCards.map(card => (
                  <div
                    key={card.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, card.id)}
                    onDragEnd={handleDragEnd}
                    className={`${cardBg} border ${cardBorder} rounded-md p-2 cursor-grab active:cursor-grabbing transition-opacity duration-150 ${
                      draggingId === card.id ? 'opacity-40' : 'opacity-100'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className={`text-[12px] font-medium ${textPrimary} truncate mr-1`}>{card.company}</span>
                      <span className={`text-[10px] font-bold ${getScoreColor(card.score, isDark)} shrink-0`}>{card.score}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className={`text-[11px] ${textMuted}`}>{card.segment}</span>
                      <span className={`text-[11px] font-medium ${textSecondary}`}>{formatCurrency(card.value)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Mobile scroll hint */}
      <p className="md:hidden text-[12px] text-p5-text-tertiary px-3 py-2 text-center">{t.kanban.scrollHint}</p>
    </div>
  );
};

export default InteractiveCRMKanban;