import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/i18n/LanguageContext';

const pipelineData = [
  { label: 'Prospecção', value: 42, color: 'hsl(222, 76%, 55%)' },
  { label: 'Qualificação', value: 28, color: 'hsl(210, 70%, 50%)' },
  { label: 'Proposta', value: 18, color: 'hsl(195, 65%, 48%)' },
  { label: 'Fechamento', value: 12, color: 'hsl(168, 75%, 42%)' },
];

const deals = [
  { company: 'TechNova Soluções', value: 'R$ 45.000', score: 92, status: 'hot' },
  { company: 'Grupo Vertice', value: 'R$ 120.000', score: 87, status: 'warm' },
  { company: 'DataFlow Analytics', value: 'R$ 68.000', score: 78, status: 'warm' },
];

const kpis = [
  { label: 'Pipeline', value: 'R$ 931K', change: '+12%' },
  { label: 'Win Rate', value: '34%', change: '+4.2%' },
  { label: 'Deals', value: '127', change: '+18' },
];

const HeroDashboard = () => {
  const [animated, setAnimated] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const timer = setTimeout(() => setAnimated(true), 600);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="relative w-full">
      {/* Main dashboard window */}
      <div
        className="rounded-xl border overflow-hidden"
        style={{
          background: 'hsl(222, 30%, 12%)',
          borderColor: 'hsla(222, 20%, 25%, 0.5)',
          boxShadow: '0 32px 64px -16px rgba(0,0,0,0.5), 0 0 0 1px hsla(222, 20%, 25%, 0.3)',
        }}
      >
        {/* Window chrome */}
        <div className="flex items-center gap-2 px-4 py-2.5 border-b" style={{ borderColor: 'hsla(222, 20%, 20%, 0.6)' }}>
          <div className="flex gap-1.5">
            <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#FF5F57' }} />
            <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#FFBD2E' }} />
            <div className="w-2.5 h-2.5 rounded-full" style={{ background: '#28CA41' }} />
          </div>
          <span className="ml-3 text-[11px] font-medium text-white/30">{t.hero.dashboardTitle}</span>
        </div>

        {/* KPI bar */}
        <div className="grid grid-cols-3 gap-px border-b" style={{ borderColor: 'hsla(222, 20%, 20%, 0.6)', background: 'hsla(222, 20%, 20%, 0.3)' }}>
          {kpis.map((kpi, i) => (
            <div key={i} className="px-4 py-3" style={{ background: 'hsl(222, 30%, 12%)' }}>
              <p className="text-[10px] font-medium text-white/30 mb-0.5">{kpi.label}</p>
              <div className="flex items-baseline gap-1.5">
                <span className="text-sm font-bold text-white">{kpi.value}</span>
                <span className="text-[10px] font-semibold text-emerald-400">{kpi.change}</span>
              </div>
            </div>
          ))}
        </div>

        <div className="p-4 space-y-4">
          {/* Pipeline visualization */}
          <div>
            <p className="text-[10px] font-semibold text-white/40 mb-2.5 tracking-wider uppercase">{t.hero.dashboardPipeline}</p>
            <div className="flex gap-1 h-20 items-end">
              {pipelineData.map((stage, i) => (
                <div key={i} className="flex-1 flex flex-col items-center gap-1">
                  <motion.div
                    className="w-full rounded-sm"
                    style={{ background: stage.color }}
                    initial={{ height: 0 }}
                    animate={animated ? { height: `${(stage.value / 42) * 100}%` } : { height: 0 }}
                    transition={{ duration: 0.8, delay: i * 0.12, ease: [0.25, 0.1, 0.25, 1] }}
                  />
                  <span className="text-[8px] text-white/25 font-medium text-center leading-tight">{stage.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Deals list */}
          <div>
            <p className="text-[10px] font-semibold text-white/40 mb-2 tracking-wider uppercase">{t.hero.dashboardDeals}</p>
            <div className="space-y-1.5">
              {deals.map((deal, i) => (
                <motion.div
                  key={i}
                  className="flex items-center justify-between px-3 py-2 rounded-md"
                  style={{ background: 'hsla(222, 20%, 18%, 0.6)', border: '1px solid hsla(222, 20%, 22%, 0.4)' }}
                  initial={{ opacity: 0, x: 12 }}
                  animate={animated ? { opacity: 1, x: 0 } : { opacity: 0, x: 12 }}
                  transition={{ duration: 0.5, delay: 0.8 + i * 0.1 }}
                >
                  <div className="flex items-center gap-2.5">
                    <div
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ background: deal.status === 'hot' ? '#34D399' : '#FBBF24' }}
                    />
                    <span className="text-[11px] font-medium text-white/80">{deal.company}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-[10px] font-semibold text-white/50">{deal.value}</span>
                    <span className="text-[10px] font-bold text-emerald-400">{deal.score}</span>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Floating automation card */}
      <motion.div
        className="absolute -left-6 bottom-16 rounded-lg border px-4 py-3"
        style={{
          background: 'hsl(222, 30%, 14%)',
          borderColor: 'hsla(222, 20%, 25%, 0.5)',
          boxShadow: '0 16px 32px -8px rgba(0,0,0,0.4)',
          width: '180px',
        }}
        initial={{ opacity: 0, y: 16 }}
        animate={animated ? { opacity: 1, y: 0 } : { opacity: 0, y: 16 }}
        transition={{ duration: 0.6, delay: 1.2 }}
      >
        <div className="flex items-center gap-2 mb-1.5">
          <div className="w-5 h-5 rounded-md flex items-center justify-center" style={{ background: 'hsla(222, 76%, 49%, 0.15)' }}>
            <svg width="10" height="10" viewBox="0 0 16 16" fill="none">
              <path d="M2 8h4l2-4 2 8 2-4h4" stroke="hsl(222, 76%, 62%)" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <span className="text-[9px] font-semibold text-white/50 uppercase tracking-wider">{t.hero.dashboardAutomation}</span>
        </div>
        <p className="text-[11px] text-white/70 leading-snug">{t.hero.dashboardAutomationDesc}</p>
      </motion.div>

      {/* Floating AI score card */}
      <motion.div
        className="absolute -right-3 top-24 rounded-lg border px-4 py-3"
        style={{
          background: 'hsl(222, 30%, 14%)',
          borderColor: 'hsla(222, 20%, 25%, 0.5)',
          boxShadow: '0 16px 32px -8px rgba(0,0,0,0.4)',
          width: '150px',
        }}
        initial={{ opacity: 0, y: -12 }}
        animate={animated ? { opacity: 1, y: 0 } : { opacity: 0, y: -12 }}
        transition={{ duration: 0.6, delay: 1.4 }}
      >
        <p className="text-[9px] font-semibold text-white/50 uppercase tracking-wider mb-1">{t.hero.dashboardAIScore}</p>
        <div className="flex items-baseline gap-1">
          <span className="text-lg font-bold text-emerald-400">92</span>
          <span className="text-[9px] text-white/30">/100</span>
        </div>
        <div className="mt-1.5 h-1 rounded-full overflow-hidden" style={{ background: 'hsla(222, 20%, 20%, 0.8)' }}>
          <motion.div
            className="h-full rounded-full"
            style={{ background: 'linear-gradient(90deg, hsl(168, 75%, 42%), hsl(142, 70%, 50%))' }}
            initial={{ width: 0 }}
            animate={animated ? { width: '92%' } : { width: 0 }}
            transition={{ duration: 1, delay: 1.6, ease: [0.25, 0.1, 0.25, 1] }}
          />
        </div>
      </motion.div>
    </div>
  );
};

export default HeroDashboard;
