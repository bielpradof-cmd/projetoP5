import { Check } from 'lucide-react';
import { useIntersectionObserver } from '@/hooks/useIntersectionObserver';
import { useLanguage } from '@/i18n/LanguageContext';
import { WHATSAPP_URL } from '@/siteConfig';

const CTASection = () => {
  const { ref, isVisible } = useIntersectionObserver();
  const { t } = useLanguage();

  const trustSignals = [t.cta.trust1, t.cta.trust2, t.cta.trust3];

  return (
    <section
      id="cta"
      ref={ref as React.RefObject<HTMLElement>}
      className="relative py-14 md:py-18 lg:py-30 overflow-hidden"
      style={{ background: 'linear-gradient(180deg, hsl(222, 35%, 10%) 0%, hsl(222, 47%, 8%) 100%)' }}
    >
      {/* Radial glow */}
      <div
        className="absolute pointer-events-none left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        style={{
          width: '800px',
          height: '600px',
          background: 'radial-gradient(ellipse, hsla(222, 76%, 49%, 0.06) 0%, transparent 60%)',
        }}
      />

      <div className="relative z-10 w-full max-w-content mx-auto px-4 md:px-8 flex flex-col items-center text-center">
        <div
          className="transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
        >
          <p className="text-caption mb-6" style={{ color: 'hsl(222, 76%, 62%)' }}>{t.cta.sectionLabel}</p>
          <h2 className="text-display-2 text-white mb-6 max-w-[720px] whitespace-pre-line">
            {t.cta.heading}
          </h2>
          <p className="text-body max-w-[560px] mx-auto mb-10" style={{ color: 'hsl(220, 9%, 46%)' }}>
            {t.cta.body}
          </p>
          <a
            href={WHATSAPP_URL}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center px-10 py-[18px] text-lg font-semibold rounded-lg text-white transition-all duration-200 mb-8 min-h-[48px]"
            style={{
              background: 'linear-gradient(135deg, hsl(222, 76%, 49%) 0%, hsl(222, 76%, 42%) 100%)',
              boxShadow: '0 4px 24px -4px hsla(222, 76%, 49%, 0.4)',
            }}
          >
            {t.cta.button}
          </a>
          <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-4 sm:gap-6">
            {trustSignals.map((signal, i) => (
              <div key={i} className="flex items-center gap-2">
                <Check size={16} strokeWidth={1.5} style={{ color: 'hsl(222, 76%, 62%)' }} className="shrink-0" />
                <span className="text-sm" style={{ color: 'hsl(220, 9%, 46%)' }}>{signal}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTASection;
