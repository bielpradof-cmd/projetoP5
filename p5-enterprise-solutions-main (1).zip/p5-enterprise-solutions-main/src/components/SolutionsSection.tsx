import { useIntersectionObserver, useStaggeredChildren } from '@/hooks/useIntersectionObserver';
import { useLanguage } from '@/i18n/LanguageContext';

const SolutionsSection = () => {
  const { ref, isVisible } = useIntersectionObserver();
  const childrenVisible = useStaggeredChildren(isVisible, 3);
  const { t } = useLanguage();

  const solutions = [
    {
      accentColor: 'hsl(222, 76%, 49%)',
      subtitle: t.solutions.card1Subtitle,
      title: t.solutions.card1Title,
      body: t.solutions.card1Body,
      features: t.solutions.card1Features,
    },
    {
      accentColor: 'hsl(168, 75%, 32%)',
      subtitle: t.solutions.card2Subtitle,
      title: t.solutions.card2Title,
      body: t.solutions.card2Body,
      features: t.solutions.card2Features,
    },
    {
      accentColor: 'hsl(263, 70%, 58%)',
      subtitle: t.solutions.card3Subtitle,
      title: t.solutions.card3Title,
      body: t.solutions.card3Body,
      features: t.solutions.card3Features,
    },
  ];

  return (
    <section id="solutions" ref={ref as React.RefObject<HTMLElement>} className="bg-p5-bg py-14 md:py-18 lg:py-30">
      <div className="w-full max-w-content mx-auto px-4 md:px-8">
        <div
          className="mb-12 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
        >
          <p className="text-caption text-p5-action mb-4">{t.solutions.sectionLabel}</p>
          <h2 className="text-heading-1 text-p5-text-primary max-w-[560px]">{t.solutions.heading}</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {solutions.map((sol, i) => (
            <div
              key={i}
              className="group bg-p5-surface border border-p5-border rounded-lg overflow-hidden flex flex-col transition-all duration-300"
              style={{
                opacity: childrenVisible[i] ? 1 : 0,
                transform: childrenVisible[i] ? 'translateY(0)' : 'translateY(16px)',
                transitionProperty: 'opacity, transform, border-color, box-shadow',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.borderColor = sol.accentColor;
                e.currentTarget.style.boxShadow = `0 0 0 3px ${sol.accentColor}12`;
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.borderColor = '';
                e.currentTarget.style.boxShadow = '';
              }}
            >
              <div className="h-1 w-full" style={{ background: sol.accentColor }} />
              <div className="p-8 md:p-10 flex flex-col flex-1">
                <p className="text-caption text-p5-text-secondary mb-2">{sol.subtitle}</p>
                <h3 className="text-heading-2 text-p5-text-primary mb-3">{sol.title}</h3>
                <p className="text-body text-p5-text-secondary mb-6">{sol.body}</p>
                <div className="flex flex-col gap-3 mb-8 flex-1">
                  {sol.features.map((feat, fi) => (
                    <div key={fi} className="border-l-2 border-p5-border pl-3">
                      <p className="text-sm text-p5-text-primary">{feat}</p>
                    </div>
                  ))}
                </div>
                <a href="#" className="text-sm font-medium transition-opacity duration-200 hover:opacity-80" style={{ color: sol.accentColor }}>
                  {t.solutions.learnMore}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SolutionsSection;
