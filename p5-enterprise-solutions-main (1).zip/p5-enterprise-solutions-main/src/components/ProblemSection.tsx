import { LayoutGrid, Clock, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';
import { useIntersectionObserver, useStaggeredChildren } from '@/hooks/useIntersectionObserver';
import { useLanguage } from '@/i18n/LanguageContext';

const ProblemSection = () => {
  const { ref, isVisible } = useIntersectionObserver();
  const childrenVisible = useStaggeredChildren(isVisible, 3);
  const { t } = useLanguage();

  const problems = [
    { icon: LayoutGrid, heading: t.problem.card1Heading, body: t.problem.card1Body },
    { icon: Clock, heading: t.problem.card2Heading, body: t.problem.card2Body },
    { icon: TrendingDown, heading: t.problem.card3Heading, body: t.problem.card3Body },
  ];

  return (
    <section ref={ref as React.RefObject<HTMLElement>} className="relative py-14 md:py-18 lg:py-30 overflow-hidden" style={{ background: 'linear-gradient(180deg, hsl(220, 30%, 14%) 0%, hsl(222, 35%, 10%) 100%)' }}>
      {/* Subtle dot pattern */}
      <div className="absolute inset-0 pointer-events-none" style={{ opacity: 0.03 }}>
        <svg width="100%" height="100%">
          <defs>
            <pattern id="problem-dots" width="32" height="32" patternUnits="userSpaceOnUse">
              <circle cx="16" cy="16" r="1" fill="white" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#problem-dots)" />
        </svg>
      </div>

      <div className="relative z-10 w-full max-w-content mx-auto px-4 md:px-8">
        <p
          className="text-caption mb-10 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)', color: 'hsl(222, 76%, 62%)' }}
        >
          {t.problem.sectionLabel}
        </p>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8">
          <div
            className="lg:col-span-7 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
            style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
          >
            <h2 className="text-heading-1 text-white max-w-[520px] mb-6">{t.problem.heading}</h2>
            <p className="text-body-large max-w-[480px]" style={{ lineHeight: 1.75, color: 'hsl(220, 9%, 64%)' }}>
              {t.problem.body}
            </p>
          </div>
          <div className="lg:col-span-5 flex flex-col gap-4">
            {problems.map((problem, i) => (
              <div
                key={i}
                className="rounded-lg p-6 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
                style={{
                  opacity: childrenVisible[i] ? 1 : 0,
                  transform: childrenVisible[i] ? 'translateY(0)' : 'translateY(16px)',
                  background: 'hsla(222, 25%, 15%, 0.6)',
                  border: '1px solid hsla(222, 20%, 22%, 0.4)',
                  backdropFilter: 'blur(8px)',
                }}
              >
                <div className="w-10 h-10 rounded-lg flex items-center justify-center mb-3" style={{ backgroundColor: 'hsla(222, 76%, 49%, 0.1)' }}>
                  <problem.icon size={20} strokeWidth={1.5} style={{ color: 'hsl(222, 76%, 65%)' }} />
                </div>
                <h3 className="text-base font-semibold text-white mb-1.5">{problem.heading}</h3>
                <p className="text-sm leading-relaxed" style={{ color: 'hsl(220, 9%, 46%)' }}>{problem.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
