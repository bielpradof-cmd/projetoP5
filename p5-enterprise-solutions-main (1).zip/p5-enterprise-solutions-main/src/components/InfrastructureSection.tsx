import { Server, Lock, Cpu, Shield } from 'lucide-react';
import { useIntersectionObserver, useStaggeredChildren } from '@/hooks/useIntersectionObserver';
import { useLanguage } from '@/i18n/LanguageContext';

const InfrastructureSection = () => {
  const { ref, isVisible } = useIntersectionObserver();
  const badgesVisible = useStaggeredChildren(isVisible, 4);
  const { t } = useLanguage();

  const badges = [
    { icon: Server, label: t.infrastructure.badge1 },
    { icon: Lock, label: t.infrastructure.badge2 },
    { icon: Cpu, label: t.infrastructure.badge3 },
    { icon: Shield, label: t.infrastructure.badge4 },
  ];

  return (
    <section ref={ref as React.RefObject<HTMLElement>} className="bg-p5-bg py-14 md:py-18 lg:py-30">
      <div className="w-full max-w-content mx-auto px-4 md:px-8">
        <p
          className="text-caption text-p5-action mb-10 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
        >
          {t.infrastructure.sectionLabel}
        </p>

        {/* Metrics bar */}
        <div
          className="mb-10 rounded-lg border px-6 md:px-10 py-6 transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
          style={{
            backgroundColor: 'hsl(214, 100%, 97%)',
            borderColor: 'hsl(214, 70%, 85%)',
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(16px)',
          }}
        >
          <p className="text-[15px] font-medium text-p5-action">{t.infrastructure.metricsBar}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          <div
            className="transition-all duration-[600ms] ease-[cubic-bezier(0.4,0,0.2,1)]"
            style={{ opacity: isVisible ? 1 : 0, transform: isVisible ? 'translateY(0)' : 'translateY(16px)' }}
          >
            <h2 className="text-heading-1 text-p5-text-primary mb-6">{t.infrastructure.heading}</h2>
            <p className="text-body-large text-p5-text-secondary" style={{ lineHeight: 1.75 }}>
              {t.infrastructure.body}
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {badges.map((badge, i) => (
              <div
                key={i}
                className="group bg-p5-surface border border-p5-border rounded-lg p-8 transition-all duration-300"
                style={{
                  opacity: badgesVisible[i] ? 1 : 0,
                  transform: badgesVisible[i] ? 'translateY(0)' : 'translateY(16px)',
                  transitionProperty: 'opacity, transform, border-color, box-shadow',
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.borderColor = 'hsl(222, 76%, 49%)';
                  e.currentTarget.style.boxShadow = '0 0 0 3px hsla(222, 76%, 49%, 0.08)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.borderColor = '';
                  e.currentTarget.style.boxShadow = '';
                }}
              >
                <div className="w-12 h-12 rounded-lg bg-p5-action-surface flex items-center justify-center mb-4">
                  <badge.icon
                    size={24}
                    strokeWidth={1.5}
                    className="text-p5-action transition-transform duration-300 ease-out group-hover:rotate-12"
                  />
                </div>
                <p className="text-sm font-medium text-p5-text-primary">{badge.label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default InfrastructureSection;
