import { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '@/i18n/LanguageContext';
import { WHATSAPP_URL } from '@/siteConfig';
import LanguageSelector from './LanguageSelector';
import P5LogoTransparent from '@/assets/P5Transparent.png';

const Navigation = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const { t } = useLanguage();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 80);
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [mobileOpen]);

  const navLinks = [
    { label: t.nav.solutions, href: '#solutions' },
    { label: t.nav.whiteLabel, href: '#white-label' },
    { label: t.nav.about, href: '#framework' },
  ];

  return (
    <>
      <nav
        className="fixed top-0 left-0 right-0 z-50 h-16 flex items-center transition-all duration-300"
        style={{
          backgroundColor: scrolled ? 'rgba(250, 250, 250, 0.95)' : 'transparent',
          backdropFilter: scrolled ? 'blur(16px) saturate(180%)' : 'none',
          WebkitBackdropFilter: scrolled ? 'blur(16px) saturate(180%)' : 'none',
          borderBottom: scrolled ? '1px solid hsl(220, 13%, 91%)' : '1px solid transparent',
        }}
      >
        <div className="w-full max-w-content mx-auto px-4 md:px-8 flex items-center justify-between">
          <a href="#" className="flex items-center gap-1.5">
            <img
              src={P5LogoTransparent}
              alt="P5"
              className="h-9 w-auto object-contain block"
              style={{ imageRendering: 'crisp-edges' as any }}
            />
            <span
              className="font-wordmark text-xl transition-colors duration-300"
              style={{ letterSpacing: '-0.01em', color: scrolled ? '#0A0A0A' : '#FFFFFF' }}
            >
              Solutions
            </span>
          </a>

          <div className="hidden lg:flex items-center gap-8">
            {navLinks.map(link => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm font-medium transition-colors duration-300"
                style={{ color: scrolled ? '#0A0A0A' : 'rgba(255,255,255,0.7)' }}
                onMouseEnter={(e) => e.currentTarget.style.color = scrolled ? 'hsl(222, 76%, 49%)' : '#FFFFFF'}
                onMouseLeave={(e) => e.currentTarget.style.color = scrolled ? '#0A0A0A' : 'rgba(255,255,255,0.7)'}
              >
                {link.label}
              </a>
            ))}
          </div>

          <div className="hidden lg:flex items-center gap-3">
            <LanguageSelector />
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center h-9 px-5 text-sm font-semibold rounded-lg text-white transition-all duration-200"
              style={{
                background: 'linear-gradient(135deg, hsl(222, 76%, 49%) 0%, hsl(222, 76%, 42%) 100%)',
                boxShadow: '0 2px 12px -2px hsla(222, 76%, 49%, 0.3)',
              }}
            >
              {t.nav.scheduleDiagnostic}
            </a>
          </div>

          <button
            className="lg:hidden p-2 transition-colors duration-300"
            style={{ color: scrolled ? '#0A0A0A' : '#FFFFFF' }}
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu size={24} strokeWidth={1.5} />
          </button>
        </div>
      </nav>

      {mobileOpen && (
        <div className="fixed inset-0 z-[60] flex flex-col" style={{ background: 'hsl(222, 47%, 8%)' }}>
          <div className="flex items-center justify-between h-16 px-4 md:px-8 pt-2">
            <div className="flex items-center gap-1.5">
              <img
                src={P5LogoTransparent}
                alt="P5"
                className="h-9 w-auto object-contain block"
                style={{ imageRendering: 'crisp-edges' as any }}
              />
              <span className="font-wordmark text-xl text-white" style={{ letterSpacing: '-0.01em' }}>
                Solutions
              </span>
            </div>
            <div className="flex items-center gap-3">
              <LanguageSelector />
              <button
                className="p-2 text-white min-w-[44px] min-h-[44px] flex items-center justify-center"
                onClick={() => setMobileOpen(false)}
                aria-label="Close menu"
              >
                <X size={24} strokeWidth={1.5} />
              </button>
            </div>
          </div>
          <div className="flex-1 flex flex-col items-center justify-center gap-8 pt-[88px]">
            {navLinks.map(link => (
              <a
                key={link.href}
                href={link.href}
                onClick={() => setMobileOpen(false)}
                className="text-[32px] font-semibold text-white min-h-[56px] flex items-center"
              >
                {link.label}
              </a>
            ))}
            <a
              href={WHATSAPP_URL}
              target="_blank"
              rel="noopener noreferrer"
              onClick={() => setMobileOpen(false)}
              className="mt-8 inline-flex items-center justify-center h-12 px-8 text-base font-semibold rounded-lg text-white min-h-[48px]"
              style={{ background: 'linear-gradient(135deg, hsl(222, 76%, 49%) 0%, hsl(222, 76%, 42%) 100%)' }}
            >
              {t.nav.scheduleDiagnostic}
            </a>
          </div>
        </div>
      )}
    </>
  );
};

export default Navigation;
