import { useLanguage } from '@/i18n/LanguageContext';
import P5LogoTransparent from '@/assets/P5Transparent.png';

const Footer = () => {
  const { t } = useLanguage();

  const footerColumns = [
    { label: t.footer.solutionsLabel, links: t.footer.solutionsLinks },
    { label: t.footer.companyLabel, links: t.footer.companyLinks },
    { label: t.footer.partnerLabel, links: t.footer.partnerLinks },
  ];

  return (
    <footer style={{ background: 'hsl(222, 47%, 8%)', borderTop: '1px solid hsla(222, 20%, 22%, 0.4)' }}>
      <div className="w-full max-w-content mx-auto px-4 md:px-8 py-14 md:py-18 lg:py-20">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          <div className="pb-8 sm:pb-0">
            <div className="flex items-center gap-1.5 mb-2">
              <img
                src={P5LogoTransparent}
                alt="P5"
                className="h-7 w-auto object-contain block"
                style={{ imageRendering: 'crisp-edges' as any }}
              />
              <span className="font-wordmark text-lg text-white" style={{ letterSpacing: '-0.01em' }}>
                Solutions
              </span>
            </div>
            <p className="text-sm mb-4 leading-relaxed whitespace-pre-line" style={{ color: 'hsl(220, 9%, 46%)' }}>
              {t.footer.tagline}
            </p>
            <p className="text-sm" style={{ color: 'hsl(220, 9%, 46%)' }}>{t.footer.location}</p>
          </div>
          {footerColumns.map((col) => (
            <div key={col.label} className="pb-8 sm:pb-0">
              <p className="text-[11px] font-semibold uppercase tracking-wider mb-4" style={{ color: 'hsl(220, 9%, 46%)' }}>
                {col.label}
              </p>
              <ul className="flex flex-col gap-2.5">
                {col.links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm transition-colors duration-200 hover:text-white" style={{ color: 'hsl(220, 9%, 64%)' }}>
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
      <div style={{ borderTop: '1px solid hsla(222, 20%, 22%, 0.4)' }}>
        <div className="w-full max-w-content mx-auto px-4 md:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <p className="text-sm" style={{ color: 'hsl(220, 9%, 46%)' }}>{t.footer.copyright}</p>
          <div className="flex items-center gap-1 text-sm" style={{ color: 'hsl(220, 9%, 46%)' }}>
            <a href="#" className="transition-colors duration-200 hover:text-white">{t.footer.privacy}</a>
            <span className="mx-1">·</span>
            <a href="#" className="transition-colors duration-200 hover:text-white">{t.footer.terms}</a>
            <span className="mx-1">·</span>
            <a href="#" className="transition-colors duration-200 hover:text-white">{t.footer.cookies}</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
